//
//  Robonik.swift
//  ChatTest
//
//  Created by Vishakan U S on 30 May 2022.
//

import SwiftUI

@main
struct ChatTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
