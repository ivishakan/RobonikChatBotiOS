//
//  BotResponse.swift
//  ChatTest
//
//  Created by Vishakan U S on 30 May 2022.
//

import Foundation


func getBotResponse(message: String) -> String {
    let tempMessage = message.lowercased()
    
    if tempMessage.contains("hello") {
        return "Hey there!"
    } else if tempMessage.contains("hi") {
        return "Hey there!"
    } else if tempMessage.contains("hey") {
        return "Hey there!"
    } else if tempMessage.contains("up for some hypothetical questions?") {
        return "ummm, sure i guess"
    } else if tempMessage.contains("are you born or raised") {
        return "neither, created @ Jain University FET campus, Bangalore"
    } else if tempMessage.contains("can we go on a date") {
        return "Sorry, ask Vishakan"
    } else if tempMessage.contains("goodbye") {
        return "Talk to you later!"
    } else if tempMessage.contains("I'm fine too") {
        return "Glad to hear, how may i help you today"
    } else if tempMessage.contains("how are you") {
        return "I'm fine, how about you?"
    } else if tempMessage.contains("what is your age") {
        return "I'm not supposed to say that, sorry"
    } else if tempMessage.contains("does god exist") {
        return "If god is the one who created us, Vishakan created me, so yes god exists"
    } else {
        return "Low battery! Talk to you later"
    }
}
